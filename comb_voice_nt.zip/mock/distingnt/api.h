// MOCK of the distingNT API - for host-side wiring tests ONLY. It is a stand-in written from memory,
// NOT the real header. The real one is at https://github.com/expertsleepersltd/distingNT_API
#pragma once
#include <stdint.h>
#include <stddef.h>

enum { kNT_unitNone, kNT_unitEnum, kNT_unitDb, kNT_unitPercent, kNT_unitHz, kNT_unitSemitones, kNT_unitCents,
       kNT_unitMs, kNT_unitAudioInput, kNT_unitCvInput, kNT_unitAudioOutput, kNT_unitOutputMode };

struct _NT_parameter { const char* name; int16_t min; int16_t max; int16_t def; uint8_t unit; uint8_t scaling; const char* const* enumStrings; };
static const char* const _modeStrings[] = { "Add", "Replace" };
#define NT_PARAMETER_AUDIO_INPUT( n, mn, df ) { n, mn, 28, df, kNT_unitAudioInput, 0, NULL },
#define NT_PARAMETER_CV_INPUT( n, mn, df ) { n, mn, 28, df, kNT_unitCvInput, 0, NULL },
#define NT_PARAMETER_AUDIO_OUTPUT_WITH_MODE( n, mn, df ) { n, mn, 28, df, kNT_unitAudioOutput, 0, NULL }, { n " mode", 0, 1, 0, kNT_unitOutputMode, 0, _modeStrings },

struct _NT_parameterPage { const char* name; uint8_t numParams; const uint8_t* params; };
struct _NT_parameterPages { uint32_t numPages; const _NT_parameterPage* pages; };

struct _NT_algorithm { const _NT_parameter* parameters; const _NT_parameterPages* parameterPages; int16_t* v; };
struct _NT_algorithmRequirements { uint32_t numParameters; uint32_t sram, dram, dtc, itc; };
struct _NT_algorithmMemoryPtrs { uint8_t *sram, *dram, *dtc, *itc; };
struct _NT_globals { float sampleRate; uint32_t maxFramesPerStep; float* workBuffer; };
extern _NT_globals NT_globals;

struct _NT_factory
{
	uint32_t guid; const char* name; const char* description; uint32_t numSpecifications;
	void (*calculateRequirements)( _NT_algorithmRequirements&, const int32_t* );
	_NT_algorithm* (*construct)( const _NT_algorithmMemoryPtrs&, const _NT_algorithmRequirements&, const int32_t* );
	void (*parameterChanged)( _NT_algorithm*, int );
	void (*step)( _NT_algorithm*, float*, int );
	bool (*draw)( _NT_algorithm* );
	void (*midiRealtime)( _NT_algorithm*, uint8_t );
	void (*midiMessage)( _NT_algorithm*, uint8_t, uint8_t, uint8_t );
};
typedef int _NT_selector;
enum { kNT_selector_version, kNT_selector_numFactories, kNT_selector_factoryInfo };
#define kNT_apiVersionCurrent 1
#define NT_MULTICHAR( a, b, c, d ) ( (uint32_t)(a) | ( (uint32_t)(b) << 8 ) | ( (uint32_t)(c) << 16 ) | ( (uint32_t)(d) << 24 ) )
extern "C++" uintptr_t pluginEntry( _NT_selector selector, uint32_t data );
