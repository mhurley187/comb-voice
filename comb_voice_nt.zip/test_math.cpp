#include "nt_math.h"
#include <math.h>
#include <stdio.h>
int main()
{
	double me2=0, me=0, ms=0, ma=0, msq=0, mfl=0; 
	for (float x = -20.f; x <= 20.f; x += 0.0137f) { double e = fabs(ntm::exp2(x) / exp2((double)x) - 1.0); if (e > me2) me2 = e; }
	for (float x = -30.f; x <= 30.f; x += 0.0211f) { double e = fabs(ntm::exp(x) / exp((double)x) - 1.0); if (e > me) me = e; }
	for (float x = -20.f; x <= 20.f; x += 0.0173f) { double e = fabs(ntm::sin(x) - sin((double)x)); if (e > ms) ms = e; }
	for (float y = -3.f; y <= 3.f; y += 0.041f) for (float x = -3.f; x <= 3.f; x += 0.043f)
	{ double e = fabs(ntm::atan2(y, x) - atan2((double)y, (double)x)); if (e > ma) ma = e; }
	for (float x = 1e-4f; x <= 4.f; x += 0.0031f) { double e = fabs(ntm::sqrt(x) / sqrt((double)x) - 1.0); if (e > msq) msq = e; }
	for (float x = -50.f; x <= 50.f; x += 0.37f) { double e = fabs(ntm::floor(x) - floor((double)x)); if (e > mfl) mfl = e; }
	printf("exp2 rel %.2e  exp rel %.2e  sin abs %.2e  atan2 abs %.2e  sqrt rel %.2e  floor %.0e\n", me2, me, ms, ma, msq, mfl);
	bool ok = me2 < 1e-5 && me < 1e-5 && ms < 2e-6 && ma < 2e-5 && msq < 1e-6 && mfl == 0;
	puts(ok ? "MATH TEST: PASS" : "MATH TEST: FAIL");
	return ok ? 0 : 1;
}
